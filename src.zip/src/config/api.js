export const API_URL = "https://chatify-api.up.railway.app";
